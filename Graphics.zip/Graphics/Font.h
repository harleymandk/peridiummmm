#ifndef __FONT_H__
#define __FONT_H__

#include "Bitmap.h"

#include <stdint.h>

typedef struct Font Font;

typedef int CharacterWidthFontFunction(const Font *font,int c);
typedef int StringWidthFontFunction(const Font *font,const void *str);
typedef void DrawCharacterFontFunction(Bitmap *bitmap,const Font *font,int x,int y,Pixel col,int c);
typedef void DrawStringFontFunction(Bitmap *bitmap,const Font *font,int x,int y,Pixel col,const void *str);

struct Font
{
	int height;

	CharacterWidthFontFunction *charwidthfunc;
	StringWidthFontFunction *stringwidthfunc;
	DrawCharacterFontFunction *drawcharfunc;
	DrawStringFontFunction *drawstringfunc;
	// TODO: Add compositing functions.
};

static inline int HeightOfFont(const Font *font)
{
	return font->height;
}

static inline int WidthOfCharacter(const Font *font,int c)
{
	return font->charwidthfunc(font,c);
}

static inline int WidthOfString(const Font *font,const void *str)
{
	return font->stringwidthfunc(font,str);
}

static inline void DrawCharacter(Bitmap *bitmap,const Font *font,int x,int y,Pixel col,int c)
{
	font->drawcharfunc(bitmap,font,x,y,col,c);
}

static inline void DrawString(Bitmap *bitmap,const Font *font,int x,int y,Pixel col,const void *str)
{
	font->drawstringfunc(bitmap,font,x,y,col,str);
}

static inline void DrawStringToTheLeftOf(Bitmap *bitmap,const Font *font,
int x,int y,Pixel col,const void *str)
{
	int stringwidth=WidthOfString(font,str);
	DrawString(bitmap,font,x-stringwidth+1,y,col,str);
}

static inline void DrawStringCenteredInRectangle(Bitmap *bitmap,const Font *font,
int x,int y,int w,int h,Pixel col,const void *str)
{
	int stringwidth=WidthOfString(font,str);
	int stringheight=HeightOfFont(font);
	DrawString(bitmap,font,x+(w-stringwidth)/2,y+(h-stringheight)/2,col,str);
}

int WidthOfSimpleString(const Font *font,const void *str);
void DrawSimpleString(Bitmap *bitmap,const Font *font,int x,int y,Pixel col,const void *str);

#endif
