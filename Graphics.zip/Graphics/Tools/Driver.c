#include <getopt.h>
#include <stdio.h>

void RunTool(int argc,const char **argv)
{
}

