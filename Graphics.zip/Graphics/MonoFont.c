#include "MonoFont.h"
#include "Drawing.h"

int WidthOfMonoFontCharacter(const Font *font,int c)
{
	const MonoFont *self=(const MonoFont *)font;

	if(c<self->firstglyph || c>self->lastglyph) return 0;
	if(!self->glyphs[c-self->firstglyph]) return 0;

	const uint8_t *data=self->glyphs[c-self->firstglyph];
	return data[0];
}

void DrawMonoFontCharacter(Bitmap *bitmap,const Font *font,int x,int y,Pixel col,int c)
{
	const MonoFont *self=(const MonoFont *)font;

	if(c<self->firstglyph || c>self->lastglyph) return;
	if(!self->glyphs[c-self->firstglyph]) return;

	const uint8_t *data=self->glyphs[c-self->firstglyph];
	int width=data[1];
	int height=data[2];
	const uint8_t *spans=&data[3];

	for(int dy=0;dy<height;dy++)
	{
		int dx=0;
		while(dx<width)
		{
			dx+=*spans++;
			if(dx>=width) break;

			int length=*spans++;
			DrawHorizontalLine(bitmap,x+dx,y+dy,length,col);
			dx+=length;
		}
	}
}
