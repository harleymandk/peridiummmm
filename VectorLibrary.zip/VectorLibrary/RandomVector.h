#ifndef __RANDOM_VECTOR_H__
#define __RANDOM_VECTOR_H__

#include "Vector.h"

vec3_t vec3cuberand();
vec3_t vec3sphererand();

#endif


